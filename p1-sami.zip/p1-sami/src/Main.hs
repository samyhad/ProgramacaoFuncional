module Main (main) where

square x = x * x

fat :: Int -> Int
fat n = if (n==0) then 1 else n * fat(n-1)

# Usando o if simplificado
fat' :: Int -> Int
fat' n | n < 0     = error "numero negativo"
       | n == 0    = 1
       | otherwise = n * fat'(n-1)

#escrevendo uma lista
#lista em haskell devem ter todos os mesmo tipo
#Devolver o tamanho de um array length::[a]-> Int (lista do tipo a retorna um Int)
#lista infinita [1..]
#take []
#list comprehesion -> [x | x <- [1 .. ], primo x] é igual a lista de todos os números primos
# lista vazia = []
# adicionar item na lista item : [lista] que tem a seguinte estrutura: a->[a]->[a]
# 1:[] é igual que começa em 1 e termina em uma lista vazia 
# 2:(1:[]) = 2:[1] = [2, 1]


main :: IO ()
main = do
  print (square 8.4)
  print (fat 6)
  print (fat' 10)
